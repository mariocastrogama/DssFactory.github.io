---
title: Projects
layout: collection
permalink: /projects/
collection: projects
entries_layout: grid
---

Sample document listing for the collection `_projects`.
